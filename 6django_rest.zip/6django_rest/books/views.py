from django.views.generic import ListView
from .models import post

# Create your views here.
class BookListView(ListView):
    model = post
    template_name = 'book.html'
    